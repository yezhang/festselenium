package com.nemo.festselenium.fixture;

/**
 * Control the JPanelFixture in selenium server side
 * 
 * @see org.fest.swing.fixture.JPanelFixture
 * 
 * @author CanHua Li
 * 
 */
public class PanelFixture extends ComponentFixture<PanelFixture> {
	public PanelFixture(ComponentContext context) {
		super(context);
	}

}
